﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;


namespace Workshop_Tecnologia.BLL
{
    public class InscricaoBLL
    {
        private MysqlDAL var = new MysqlDAL();

        public Boolean validar(string email, string senha)
        {
            string sql = string.Format($@"SELECT * FROM inscricao WHERE email = '{email}' and senha = '{senha}';")

                DataTable data = var.ExecutarConsulta(sql);

            
        }
    }
}