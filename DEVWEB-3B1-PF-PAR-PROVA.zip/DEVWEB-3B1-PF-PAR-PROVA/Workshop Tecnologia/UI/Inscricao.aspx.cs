﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Workshop_Tecnologia.UI
{
    public partial class inscricao : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected System.Void nome_TextChanged(System.Object sender, System.EventArgs e)
        {
            InscricaoDTO inscricaoDTO = new InscricaoDTO();
            inscricaoDTO.nome = nome_TextChanged.Text;

            InscricaoBLL inscricaoBLL = new InscricaoBLL();
            inscricaoBLL.nome = nome_TextChanged.Text();

        }

        protected System.Void email_TextChanged(System.Object sender, System.EventArgs e)
        {

        }

        protected System.Void telefone_TextChanged(System.Object sender, System.EventArgs e)
        {

        }

        protected System.Void Salvar_Click(System.Object sender, System.EventArgs e)
        {

        }
    }
}