﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade_Mamifero
{
    class Mamífero:Animal
    {
        public Mamífero(string nome): base(nome) 
        {

        }
    }
}
