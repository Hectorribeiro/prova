﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade_Mamifero
{
    class Morcego:Mamífero
    {

        public void voar()
        {

        }
    }
}
